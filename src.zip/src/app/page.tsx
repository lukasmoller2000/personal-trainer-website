import { Hero } from "@/components/sections/Hero";
import { Stats } from "@/components/sections/Stats";
import { Offerings } from "@/components/sections/Offerings";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { AboutTeaser } from "@/components/sections/AboutTeaser";
import { Testimonials } from "@/components/sections/Testimonials";
import { FAQ } from "@/components/sections/FAQ";
import { ContactForm } from "@/components/sections/ContactForm";

export default function HomePage() {
  return (
    <>
      <Hero />
      <Stats />
      <Offerings compact />
      <HowItWorks />
      <AboutTeaser />
      <Testimonials />
      <FAQ limit={4} />
      <ContactForm />
    </>
  );
}
