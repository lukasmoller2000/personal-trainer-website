import Link from "next/link";
import { Button } from "@/components/ui/Button";

export default function NotFound() {
  return (
    <section className="flex min-h-screen flex-col items-center justify-center px-4 text-center">
      <p className="text-sm uppercase tracking-[0.2em] text-sage">404</p>
      <h1 className="mt-3 font-display text-4xl font-semibold text-ink">Siden findes ikke</h1>
      <p className="mt-3 max-w-md text-ink/70">
        Linket virker ikke. Gå tilbage til forsiden, eller book en tid.
      </p>
      <div className="mt-8 flex gap-3">
        <Button href="/">Forside</Button>
        <Button href="/booking" variant="outline">
          Book
        </Button>
      </div>
      <Link href="/kontakt" className="mt-6 text-sm text-ink/50 hover:text-ink">
        Kontakt
      </Link>
    </section>
  );
}
