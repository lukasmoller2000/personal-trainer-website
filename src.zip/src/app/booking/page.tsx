import type { Metadata } from "next";
import { BookingWizard } from "@/components/booking/BookingWizard";

export const metadata: Metadata = {
  title: "Book",
  description: "Book 1 personlig træning eller et forløb hos Nordic Fit.",
};

export default async function BookingPage({
  searchParams,
}: {
  searchParams: Promise<{ produkt?: string }>;
}) {
  const { produkt } = await searchParams;

  return (
    <>
      <section className="bg-cream pt-32 pb-10 md:pt-40">
        <div className="container-custom mx-auto max-w-3xl text-center">
          <span className="mb-4 inline-block text-sm font-medium uppercase tracking-[0.2em] text-sage">
            Booking
          </span>
          <h1 className="font-display text-4xl font-semibold text-ink md:text-5xl">
            Book træning
          </h1>
          <p className="mt-4 text-lg text-ink/70">
            Vælg én session eller et forløb, find en tid, og udfyld dine oplysninger.
          </p>
        </div>
      </section>
      <section className="pb-20">
        <div className="container-custom">
          <BookingWizard initialProductId={produkt} />
        </div>
      </section>
    </>
  );
}
