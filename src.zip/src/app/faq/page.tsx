import type { Metadata } from "next";
import { FAQ } from "@/components/sections/FAQ";
import { ContactForm } from "@/components/sections/ContactForm";

export const metadata: Metadata = {
  title: "FAQ",
  description: "Ofte stillede spørgsmål om personlig træning, forløb og booking hos Nordic Fit.",
};

export default function FAQPage() {
  return (
    <>
      <section className="bg-cream pt-32 pb-10 md:pt-40">
        <div className="container-custom mx-auto max-w-3xl text-center">
          <span className="mb-4 inline-block text-sm font-medium uppercase tracking-[0.2em] text-sage">
            FAQ
          </span>
          <h1 className="font-display text-4xl font-semibold text-ink md:text-5xl">
            Spørgsmål og svar
          </h1>
        </div>
      </section>
      <FAQ showHeading={false} />
      <ContactForm />
    </>
  );
}
