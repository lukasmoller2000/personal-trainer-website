import type { Metadata } from "next";
import { AnimatedSection } from "@/components/ui/AnimatedSection";
import { siteConfig } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Privatlivspolitik",
  description: "Hvordan Nordic Fit behandler personoplysninger.",
};

export default function PrivacyPage() {
  return (
    <>
      <section className="bg-cream pt-32 pb-8 md:pt-40">
        <div className="container-custom max-w-3xl">
          <h1 className="font-display text-4xl font-semibold text-ink">Privatlivspolitik</h1>
          <p className="mt-2 text-ink/55">Senest opdateret: august 2026</p>
        </div>
      </section>
      <AnimatedSection>
        <div className="container-custom max-w-3xl space-y-6 leading-relaxed text-ink/80">
          <section>
            <h2 className="mb-2 font-display text-2xl font-semibold text-ink">1. Dataansvarlig</h2>
            <p>
              {siteConfig.name} er dataansvarlig for de oplysninger, du giver via hjemmesiden,
              herunder booking og kontaktformular.
            </p>
          </section>
          <section>
            <h2 className="mb-2 font-display text-2xl font-semibold text-ink">2. Hvad vi indsamler</h2>
            <p>
              Navn, email, telefon, dit mål og eventuelle bemærkninger, når du booker eller skriver.
              Vi bruger oplysningerne til at gennemføre træning og svare dig.
            </p>
          </section>
          <section>
            <h2 className="mb-2 font-display text-2xl font-semibold text-ink">3. Opbevaring</h2>
            <p>
              Bookinger gemmes, så tider ikke dobbeltbookes. Vi sælger ikke dine data. Du kan
              skrive til {siteConfig.links.email} for indsigt eller sletning.
            </p>
          </section>
        </div>
      </AnimatedSection>
    </>
  );
}
