import type { Metadata } from "next";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { ContactForm } from "@/components/sections/ContactForm";
import { AnimatedSection } from "@/components/ui/AnimatedSection";
import { Card } from "@/components/ui/Card";
import { siteConfig } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Kontakt",
  description: "Kontakt Nordic Fit — book træning eller stil et spørgsmål.",
};

const info = [
  {
    icon: Mail,
    label: "Email",
    value: siteConfig.links.email,
    href: `mailto:${siteConfig.links.email}`,
  },
  {
    icon: Phone,
    label: "Telefon",
    value: siteConfig.links.phone,
    href: `tel:${siteConfig.links.phone.replace(/\s/g, "")}`,
  },
  {
    icon: MapPin,
    label: "Sted",
    value: siteConfig.address,
    href: undefined,
  },
  {
    icon: Clock,
    label: "Tider",
    value: siteConfig.hours,
    href: undefined,
  },
];

export default function ContactPage() {
  return (
    <>
      <section className="bg-forest pt-32 pb-16 text-cream md:pt-40">
        <div className="container-custom mx-auto max-w-3xl text-center">
          <span className="mb-4 inline-block text-sm font-medium uppercase tracking-[0.2em] text-gold">
            Kontakt
          </span>
          <h1 className="font-display text-4xl font-semibold md:text-5xl">Skriv eller book</h1>
          <p className="mt-4 text-lg text-cream/75">
            Vil du i gang med det samme? Gå til booking. Har du et spørgsmål, så skriv her.
          </p>
        </div>
      </section>

      <AnimatedSection className="pb-0">
        <div className="container-custom grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {info.map((item) => (
            <Card key={item.label} hover={false} className="text-center">
              <item.icon className="mx-auto mb-3 h-6 w-6 text-sage" />
              <p className="text-sm text-ink/55">{item.label}</p>
              {item.href ? (
                <a href={item.href} className="font-medium text-ink hover:text-sage">
                  {item.value}
                </a>
              ) : (
                <p className="font-medium text-ink">{item.value}</p>
              )}
            </Card>
          ))}
        </div>
      </AnimatedSection>

      <ContactForm showHeading={false} />
    </>
  );
}
