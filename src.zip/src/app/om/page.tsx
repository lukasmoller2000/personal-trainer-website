import type { Metadata } from "next";
import Image from "next/image";
import { Card } from "@/components/ui/Card";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { AnimatedSection } from "@/components/ui/AnimatedSection";
import { Button } from "@/components/ui/Button";
import { ContactForm } from "@/components/sections/ContactForm";
import { siteConfig } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Om mig",
  description: `Mød ${siteConfig.trainer} — personlig træner hos Nordic Fit i København.`,
};

const values = [
  {
    title: "Ærlighed",
    text: "Ingen mirakelkure. Vi træner det, der virker, og dropper det, der bare ser godt ud på Instagram.",
  },
  {
    title: "Kontinuitet",
    text: "Resultater kommer af uger, der kan holdes. Programmet skal passe til dit liv — ikke omvendt.",
  },
  {
    title: "Teknik først",
    text: "Vi bygger styrke på bevægelser, du kan stole på, så du kan træne i årevis uden unødige skader.",
  },
];

export default function AboutPage() {
  return (
    <>
      <section className="bg-forest pt-32 pb-16 text-cream md:pt-40">
        <div className="container-custom mx-auto max-w-3xl text-center">
          <span className="mb-4 inline-block text-sm font-medium uppercase tracking-[0.2em] text-gold">
            Om mig
          </span>
          <h1 className="font-display text-4xl font-semibold md:text-6xl">
            Personlig træning uden støj
          </h1>
        </div>
      </section>

      <AnimatedSection>
        <div className="container-custom grid items-center gap-12 lg:grid-cols-2">
          <div className="relative aspect-[4/5] overflow-hidden rounded-3xl shadow-premium">
            <Image
              src="https://images.unsplash.com/photo-1605296867304-46d5465a13f1?w=900&q=80"
              alt={siteConfig.trainer}
              fill
              className="object-cover"
            />
          </div>
          <div>
            <SectionHeading
              align="left"
              eyebrow={siteConfig.trainer}
              title="Jeg hjælper dig med at træne, så det holder"
              description="Jeg er personlig træner i København. Klienterne er ofte travle — og de vil have et program, der er skarpt, ikke et hold, de skal presse sig ind i."
            />
            <p className="mb-4 leading-relaxed text-ink/70">
              Vi starter med dig: mål, skader, kalender og hvad der tidligere er gået galt. Så
              træner vi 1:1, og du går derfra med noget, du kan bruge næste gang også.
            </p>
            <p className="mb-8 leading-relaxed text-ink/70">
              Du kan booke én time eller et forløb. Der er ingen binding ud over det, du selv
              vælger.
            </p>
            <Button href="/booking">Book en tid</Button>
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection className="bg-sand/40">
        <div className="container-custom">
          <SectionHeading eyebrow="Tilgang" title="Sådan arbejder jeg" />
          <div className="grid gap-6 md:grid-cols-3">
            {values.map((value) => (
              <Card key={value.title}>
                <h3 className="font-display text-xl font-semibold text-ink">{value.title}</h3>
                <p className="mt-3 leading-relaxed text-ink/70">{value.text}</p>
              </Card>
            ))}
          </div>
        </div>
      </AnimatedSection>

      <ContactForm />
    </>
  );
}
