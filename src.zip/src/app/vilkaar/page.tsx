import type { Metadata } from "next";
import { AnimatedSection } from "@/components/ui/AnimatedSection";
import { siteConfig } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Handelsbetingelser",
  description: "Betingelser for booking af personlig træning hos Nordic Fit.",
};

export default function TermsPage() {
  return (
    <>
      <section className="bg-cream pt-32 pb-8 md:pt-40">
        <div className="container-custom max-w-3xl">
          <h1 className="font-display text-4xl font-semibold text-ink">Handelsbetingelser</h1>
          <p className="mt-2 text-ink/55">Senest opdateret: august 2026</p>
        </div>
      </section>
      <AnimatedSection>
        <div className="container-custom max-w-3xl space-y-6 leading-relaxed text-ink/80">
          <section>
            <h2 className="mb-2 font-display text-2xl font-semibold text-ink">1. Ydelser</h2>
            <p>
              Du kan booke én personlig træning eller et forløb. Priser fremgår på siden under
              ydelser. Træning aftales 1:1.
            </p>
          </section>
          <section>
            <h2 className="mb-2 font-display text-2xl font-semibold text-ink">2. Aflysning</h2>
            <p>
              Aflys eller flyt senest 24 timer før. Senere afbud tæller som brugt session ved
              forløb og som fuld pris ved enkeltbooking.
            </p>
          </section>
          <section>
            <h2 className="mb-2 font-display text-2xl font-semibold text-ink">3. Betaling</h2>
            <p>
              Betaling sker efter bekræftelse via MobilePay eller overførsel, medmindre andet er
              aftalt. Kontakt {siteConfig.links.email} ved spørgsmål.
            </p>
          </section>
        </div>
      </AnimatedSection>
    </>
  );
}
