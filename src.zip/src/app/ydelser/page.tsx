import type { Metadata } from "next";
import { Offerings } from "@/components/sections/Offerings";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { Button } from "@/components/ui/Button";
import { AnimatedSection } from "@/components/ui/AnimatedSection";

export const metadata: Metadata = {
  title: "Ydelser",
  description:
    "Book 1 personlig træning eller et forløb på 4, 8 eller 12 uger hos Nordic Fit i København.",
};

export default function ServicesPage() {
  return (
    <>
      <section className="bg-forest pt-32 pb-16 text-cream md:pt-40">
        <div className="container-custom mx-auto max-w-3xl text-center">
          <span className="mb-4 inline-block text-sm font-medium uppercase tracking-[0.2em] text-gold">
            Ydelser
          </span>
          <h1 className="font-display text-4xl font-semibold md:text-6xl">
            Session eller forløb
          </h1>
          <p className="mt-5 text-lg text-cream/75">
            Én time, hvis du vil mærke det. Et forløb, hvis du vil have resultater, der holder.
          </p>
        </div>
      </section>
      <Offerings />
      <HowItWorks />
      <AnimatedSection className="bg-sand/40 text-center">
        <div className="container-custom">
          <h2 className="font-display text-3xl font-semibold text-ink">Klar til at booke?</h2>
          <p className="mx-auto mt-3 mb-8 max-w-xl text-ink/70">
            Vælg en tid online. Du får bekræftelse med det samme.
          </p>
          <Button href="/booking" size="lg">
            Gå til booking
          </Button>
        </div>
      </AnimatedSection>
    </>
  );
}
