import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const siteConfig = {
  name: "Nordic Fit",
  trainer: "Lukas",
  description:
    "Personlig træning i København. Book en enkelt session eller et forløb, og få et program der passer til dit liv og dine mål.",
  url: "https://nordicfit.dk",
  location: "København",
  address: "Nørrebrogade 12, 2200 København N",
  links: {
    email: "lukas@nordicfit.dk",
    phone: "+45 42 12 34 56",
    instagram: "https://instagram.com",
    facebook: "https://facebook.com",
  },
  hours: "Man–fre 07–20 · Lør 08–12",
  nav: [
    { label: "Forside", href: "/" },
    { label: "Ydelser", href: "/ydelser" },
    { label: "Om mig", href: "/om" },
    { label: "FAQ", href: "/faq" },
    { label: "Kontakt", href: "/kontakt" },
  ],
};

export function formatPrice(amount: number) {
  return new Intl.NumberFormat("da-DK", {
    style: "currency",
    currency: "DKK",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(isoDate: string) {
  return new Intl.DateTimeFormat("da-DK", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${isoDate}T12:00:00`));
}
