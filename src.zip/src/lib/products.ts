export type ProductKind = "session" | "program";

export type Product = {
  id: string;
  kind: ProductKind;
  name: string;
  tagline: string;
  description: string;
  sessions: number;
  weeks?: number;
  durationMinutes: number;
  price: number;
  perks: string[];
  popular?: boolean;
};

export const products: Product[] = [
  {
    id: "session",
    kind: "session",
    name: "1 personlig træning",
    tagline: "Én fokuseret time",
    description:
      "En 60-minutters session med teknik, styrke og et klart næste skridt. Godt hvis du vil prøve kræfter med personlig træning, eller har brug for et enkelt, skarpt træningspas.",
    sessions: 1,
    durationMinutes: 60,
    price: 650,
    perks: [
      "60 minutter 1:1",
      "Teknik, styrke og tempo tilpasset dig",
      "Kort plan til næste træning",
      "Kan bookes løbende",
    ],
  },
  {
    id: "kickstart",
    kind: "program",
    name: "Kickstart",
    tagline: "4 uger · 8 sessioner",
    description:
      "Kom i gang rigtigt. Vi bygger vaner, retrænner teknik og sætter et program, du kan holde — også i en travl uge.",
    sessions: 8,
    weeks: 4,
    durationMinutes: 60,
    price: 4800,
    perks: [
      "8 sessioner over 4 uger",
      "Individuelt træningsprogram",
      "Opfølgning mellem sessionerne",
      "600 kr pr. session",
    ],
  },
  {
    id: "transform",
    kind: "program",
    name: "Transformation",
    tagline: "8 uger · 16 sessioner",
    description:
      "Det mest valgte forløb. Tid nok til synlige resultater, uden at det tager overhånd i kalenderen. Vi justerer programmet undervejs efter din fremgang.",
    sessions: 16,
    weeks: 8,
    durationMinutes: 60,
    price: 8800,
    popular: true,
    perks: [
      "16 sessioner over 8 uger",
      "Styrke, mobilitet og vaner",
      "Ugentlig justering af program",
      "550 kr pr. session",
    ],
  },
  {
    id: "elite",
    kind: "program",
    name: "Elite",
    tagline: "12 uger · 24 sessioner",
    description:
      "Et længere samarbejde, hvor vi går i dybden med styrke, kropssammensætning og præstation. Til dig, der vil have kontinuitet og et klart mål.",
    sessions: 24,
    weeks: 12,
    durationMinutes: 60,
    price: 12400,
    perks: [
      "24 sessioner over 12 uger",
      "Fuld programperiode med test og retest",
      "Prioriterede tider",
      "ca. 517 kr pr. session",
    ],
  },
];

export function getProduct(id: string) {
  return products.find((product) => product.id === id);
}

export const sessionProduct = products.find((p) => p.kind === "session")!;
export const programProducts = products.filter((p) => p.kind === "program");
