"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Calendar,
  Check,
  CheckCircle,
  Dumbbell,
  Layers,
} from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import {
  getCalendarDays,
  getSlotsForDate,
  isBookableDate,
  monthTitle,
  toIsoDate,
  weekdayLabels,
} from "@/lib/availability";
import { getProduct, programProducts, sessionProduct, type Product } from "@/lib/products";
import { cn, formatDate, formatPrice } from "@/lib/utils";

type Kind = "session" | "program";

type FormState = {
  name: string;
  email: string;
  phone: string;
  goal: string;
  notes: string;
};

const emptyForm: FormState = {
  name: "",
  email: "",
  phone: "",
  goal: "",
  notes: "",
};

export function BookingWizard({ initialProductId }: { initialProductId?: string }) {
  const initialProduct = initialProductId ? getProduct(initialProductId) : undefined;
  const [step, setStep] = useState(initialProduct ? 2 : 0);
  const [kind, setKind] = useState<Kind>(initialProduct?.kind ?? "session");
  const [product, setProduct] = useState<Product | undefined>(initialProduct);
  const [cursor, setCursor] = useState(() => {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() };
  });
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [takenTimes, setTakenTimes] = useState<string[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const days = useMemo(
    () => getCalendarDays(cursor.year, cursor.month),
    [cursor.year, cursor.month]
  );

  const slots = selectedDate ? getSlotsForDate(selectedDate) : [];

  useEffect(() => {
    if (!selectedDate) return;
    const iso = toIsoDate(selectedDate);
    fetch(`/api/bookings?date=${iso}`)
      .then((response) => response.json())
      .then((data: { times?: string[] }) => setTakenTimes(data.times ?? []))
      .catch(() => setTakenTimes([]));
  }, [selectedDate]);

  const goNextFromKind = (nextKind: Kind) => {
    setKind(nextKind);
    if (nextKind === "session") {
      setProduct(sessionProduct);
      setStep(2);
    } else {
      setProduct(undefined);
      setStep(1);
    }
  };

  const submit = async () => {
    if (!product || !selectedDate || !selectedTime) return;
    setSubmitting(true);
    setError(null);

    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product.id,
          date: toIsoDate(selectedDate),
          time: selectedTime,
          ...form,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error ?? "Booking kunne ikke oprettes");
      }
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Noget gik galt");
    } finally {
      setSubmitting(false);
    }
  };

  if (done && product && selectedDate && selectedTime) {
    return (
      <Card hover={false} className="mx-auto max-w-2xl text-center">
        <CheckCircle className="mx-auto mb-5 h-16 w-16 text-sage" />
        <h2 className="font-display text-3xl font-semibold text-ink">Din booking er sendt</h2>
        <p className="mt-4 text-lg text-ink/70">
          {product.name} · {formatDate(toIsoDate(selectedDate))} kl. {selectedTime}
        </p>
        <p className="mt-3 text-ink/60">
          Du hører fra mig med bekræftelse og betalingsinfo. Første møde er der, vi sætter retningen.
        </p>
        <Button href="/" className="mt-8">
          Til forsiden
        </Button>
      </Card>
    );
  }

  return (
    <div className="mx-auto max-w-4xl">
      <ol className="mb-8 grid grid-cols-4 gap-2 text-center text-xs font-medium sm:text-sm">
        {["Type", "Forløb", "Tid", "Dine info"].map((label, index) => (
          <li
            key={label}
            className={cn(
              "rounded-full px-2 py-2",
              step === index
                ? "bg-sage text-white"
                : step > index
                  ? "bg-moss/20 text-forest"
                  : "bg-sand text-ink/50"
            )}
          >
            {label}
          </li>
        ))}
      </ol>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
        >
          {step === 0 && (
            <div className="grid gap-5 md:grid-cols-2">
              <ChoiceCard
                icon={Dumbbell}
                title="1 personlig træning"
                text="60 minutter. Prøv stilen, eller book en enkelt skarp session."
                price={formatPrice(sessionProduct.price)}
                onClick={() => goNextFromKind("session")}
              />
              <ChoiceCard
                icon={Layers}
                title="Et forløb"
                text="4, 8 eller 12 uger med fast program og lavere pris pr. time."
                price="Fra 4.800 kr"
                onClick={() => goNextFromKind("program")}
              />
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4">
              {programProducts.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setProduct(item);
                    setStep(2);
                  }}
                  className="flex w-full items-start justify-between gap-4 rounded-3xl border border-sand bg-white p-5 text-left shadow-soft transition hover:border-sage"
                >
                  <div>
                    <p className="font-display text-2xl font-semibold text-ink">{item.name}</p>
                    <p className="text-ink/55">{item.tagline}</p>
                    <p className="mt-2 text-sm text-ink/70">{item.description}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="font-semibold text-ink">{formatPrice(item.price)}</p>
                    {item.popular && <p className="text-xs text-sage">Mest valgt</p>}
                  </div>
                </button>
              ))}
              <Button variant="ghost" onClick={() => setStep(0)}>
                <ArrowLeft className="h-4 w-4" /> Tilbage
              </Button>
            </div>
          )}

          {step === 2 && product && (
            <Card hover={false}>
              <div className="mb-6 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm uppercase tracking-widest text-sage">Første session</p>
                  <h3 className="font-display text-2xl font-semibold text-ink">{product.name}</h3>
                </div>
                <p className="font-semibold text-ink">{formatPrice(product.price)}</p>
              </div>

              <div className="mb-5 flex items-center justify-between">
                <button
                  type="button"
                  className="rounded-xl px-3 py-2 hover:bg-sand"
                  onClick={() =>
                    setCursor((prev) =>
                      prev.month === 0
                        ? { year: prev.year - 1, month: 11 }
                        : { year: prev.year, month: prev.month - 1 }
                    )
                  }
                >
                  ←
                </button>
                <p className="font-medium capitalize">{monthTitle(cursor.year, cursor.month)}</p>
                <button
                  type="button"
                  className="rounded-xl px-3 py-2 hover:bg-sand"
                  onClick={() =>
                    setCursor((prev) =>
                      prev.month === 11
                        ? { year: prev.year + 1, month: 0 }
                        : { year: prev.year, month: prev.month + 1 }
                    )
                  }
                >
                  →
                </button>
              </div>

              <div className="grid grid-cols-7 gap-2 text-center text-xs font-medium text-ink/50">
                {weekdayLabels.map((label) => (
                  <div key={label}>{label}</div>
                ))}
                {days.map((day, index) => {
                  if (!day) return <div key={`empty-${index}`} />;
                  const bookable = isBookableDate(day);
                  const selected = selectedDate && toIsoDate(day) === toIsoDate(selectedDate);
                  return (
                    <button
                      key={toIsoDate(day)}
                      type="button"
                      disabled={!bookable}
                      onClick={() => {
                        setSelectedDate(day);
                        setSelectedTime(null);
                      }}
                      className={cn(
                        "aspect-square rounded-xl text-sm",
                        !bookable && "cursor-not-allowed text-ink/25",
                        bookable && !selected && "hover:bg-sand",
                        selected && "bg-sage text-white"
                      )}
                    >
                      {day.getDate()}
                    </button>
                  );
                })}
              </div>

              {selectedDate && (
                <div className="mt-6">
                  <p className="mb-3 flex items-center gap-2 font-medium text-ink">
                    <Calendar className="h-4 w-4" />
                    Ledige tider {formatDate(toIsoDate(selectedDate))}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {slots.map((slot) => {
                      const taken = takenTimes.includes(slot);
                      return (
                        <button
                          key={slot}
                          type="button"
                          disabled={taken}
                          onClick={() => setSelectedTime(slot)}
                          className={cn(
                            "rounded-xl border px-4 py-2 text-sm",
                            taken && "cursor-not-allowed border-sand text-ink/30 line-through",
                            !taken && selectedTime === slot && "border-sage bg-sage text-white",
                            !taken && selectedTime !== slot && "border-sand hover:border-sage"
                          )}
                        >
                          {slot}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="mt-8 flex flex-wrap gap-3">
                <Button
                  variant="ghost"
                  onClick={() => setStep(kind === "session" ? 0 : 1)}
                >
                  <ArrowLeft className="h-4 w-4" /> Tilbage
                </Button>
                <Button disabled={!selectedDate || !selectedTime} onClick={() => setStep(3)}>
                  Fortsæt <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          )}

          {step === 3 && product && selectedDate && selectedTime && (
            <Card hover={false}>
              <h3 className="font-display text-2xl font-semibold text-ink">Dine oplysninger</h3>
              <p className="mt-1 text-ink/60">
                {product.name} · {formatDate(toIsoDate(selectedDate))} kl. {selectedTime}
              </p>
              <form
                className="mt-6 space-y-4"
                onSubmit={(event) => {
                  event.preventDefault();
                  void submit();
                }}
              >
                <div className="grid gap-4 md:grid-cols-2">
                  <Input
                    label="Navn"
                    value={form.name}
                    onChange={(value) => setForm((prev) => ({ ...prev, name: value }))}
                  />
                  <Input
                    label="Telefon"
                    type="tel"
                    value={form.phone}
                    onChange={(value) => setForm((prev) => ({ ...prev, phone: value }))}
                  />
                </div>
                <Input
                  label="Email"
                  type="email"
                  value={form.email}
                  onChange={(value) => setForm((prev) => ({ ...prev, email: value }))}
                />
                <Input
                  label="Dit mål"
                  value={form.goal}
                  onChange={(value) => setForm((prev) => ({ ...prev, goal: value }))}
                  placeholder="Styrke, vægttab, ryg, vaner..."
                />
                <div>
                  <label className="mb-2 block text-sm font-medium">Evt. bemærkninger</label>
                  <textarea
                    rows={4}
                    value={form.notes}
                    onChange={(event) => setForm((prev) => ({ ...prev, notes: event.target.value }))}
                    className="w-full resize-none rounded-2xl border border-sand px-4 py-3 outline-none ring-sage/40 focus:ring-2"
                    placeholder="Skader, træningserfaring, ønsker til sted..."
                  />
                </div>
                {error && <p className="text-sm text-red-700">{error}</p>}
                <div className="flex flex-wrap gap-3">
                  <Button variant="ghost" type="button" onClick={() => setStep(2)}>
                    <ArrowLeft className="h-4 w-4" /> Tilbage
                  </Button>
                  <Button type="submit" disabled={submitting}>
                    <Check className="h-4 w-4" />
                    {submitting ? "Booker..." : "Bekræft booking"}
                  </Button>
                </div>
              </form>
            </Card>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function ChoiceCard({
  icon: Icon,
  title,
  text,
  price,
  onClick,
}: {
  icon: typeof Dumbbell;
  title: string;
  text: string;
  price: string;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className="text-left">
      <Card className="h-full">
        <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-sage/10">
          <Icon className="h-6 w-6 text-sage" />
        </div>
        <h3 className="font-display text-2xl font-semibold text-ink">{title}</h3>
        <p className="mt-2 text-ink/70">{text}</p>
        <p className="mt-6 font-semibold text-forest">{price}</p>
      </Card>
    </button>
  );
}

function Input({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium">{label}</label>
      <input
        required
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-2xl border border-sand px-4 py-3 outline-none ring-sage/40 focus:ring-2"
      />
    </div>
  );
}
