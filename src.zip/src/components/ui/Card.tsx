"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
}

export function Card({ children, className, hover = true }: CardProps) {
  return (
    <motion.div
      className={cn(
        "rounded-3xl border border-sand bg-white p-6 shadow-soft md:p-8",
        className
      )}
      whileHover={
        hover
          ? { y: -4, boxShadow: "0 16px 48px -12px rgba(12, 22, 18, 0.16)" }
          : undefined
      }
      transition={{ duration: 0.3, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}
