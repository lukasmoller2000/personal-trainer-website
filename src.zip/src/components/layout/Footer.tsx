import Link from "next/link";
import { Mail, Phone, MapPin } from "lucide-react";
import { siteConfig } from "@/lib/utils";

const footerLinks = {
  sider: [
    { label: "Ydelser", href: "/ydelser" },
    { label: "Book", href: "/booking" },
    { label: "Om mig", href: "/om" },
    { label: "FAQ", href: "/faq" },
  ],
  legal: [
    { label: "Privatlivspolitik", href: "/privatliv" },
    { label: "Handelsbetingelser", href: "/vilkaar" },
  ],
};

export function Footer() {
  return (
    <footer className="bg-ink text-cream">
      <div className="container-custom section-padding pb-8">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link href="/" className="mb-5 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10 font-display text-lg font-bold">
                N
              </span>
              <span className="font-display text-xl font-semibold">{siteConfig.name}</span>
            </Link>
            <p className="mb-6 max-w-xs leading-relaxed text-cream/65">
              Personlig træning med {siteConfig.trainer} i {siteConfig.location}. Book en session
              eller et forløb, når det passer dig.
            </p>
            <div className="flex gap-3">
              <a
                href={siteConfig.links.instagram}
                aria-label="Instagram"
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 transition-colors hover:bg-sage"
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2">
                  <rect x="3" y="3" width="18" height="18" rx="5" />
                  <circle cx="12" cy="12" r="4" />
                  <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
                </svg>
              </a>
              <a
                href={siteConfig.links.facebook}
                aria-label="Facebook"
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 transition-colors hover:bg-sage"
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
                  <path d="M14 9h3V6h-3c-2.2 0-4 1.8-4 4v2H8v3h2v7h3v-7h3l1-3h-4V10c0-.6.4-1 1-1Z" />
                </svg>
              </a>
            </div>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold">Sider</h3>
            <ul className="space-y-3">
              {footerLinks.sider.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-cream/65 transition-colors hover:text-cream">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold">Kontakt</h3>
            <ul className="space-y-4 text-cream/65">
              <li>
                <a
                  href={`mailto:${siteConfig.links.email}`}
                  className="flex items-center gap-3 hover:text-cream"
                >
                  <Mail className="h-5 w-5 shrink-0" />
                  {siteConfig.links.email}
                </a>
              </li>
              <li>
                <a
                  href={`tel:${siteConfig.links.phone.replace(/\s/g, "")}`}
                  className="flex items-center gap-3 hover:text-cream"
                >
                  <Phone className="h-5 w-5 shrink-0" />
                  {siteConfig.links.phone}
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-5 w-5 shrink-0" />
                <span>
                  {siteConfig.address}
                  <br />
                  {siteConfig.hours}
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold">Book</h3>
            <p className="mb-4 leading-relaxed text-cream/65">
              Vælg en enkelt træning eller et forløb. Du får bekræftelse med det samme.
            </p>
            <Link
              href="/booking"
              className="inline-flex rounded-2xl bg-sage px-5 py-3 font-medium text-white transition-colors hover:bg-moss"
            >
              Book nu
            </Link>
          </div>
        </div>

        <div className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-8 md:flex-row">
          <p className="text-sm text-cream/40">
            © {new Date().getFullYear()} {siteConfig.name}. Alle rettigheder forbeholdes.
          </p>
          <div className="flex gap-6">
            {footerLinks.legal.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm text-cream/40 hover:text-cream"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
