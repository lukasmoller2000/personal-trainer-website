"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { cn, siteConfig } from "@/lib/utils";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled ? "glass py-3 shadow-soft" : "bg-transparent py-5"
      )}
    >
      <nav className="container-custom flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-forest text-cream font-display text-lg font-bold">
            N
          </span>
          <span className="hidden font-display text-xl font-semibold text-ink sm:block">
            {siteConfig.name}
          </span>
        </Link>

        <div className="hidden items-center gap-8 lg:flex">
          {siteConfig.nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="group relative text-sm font-medium text-ink/75 transition-colors hover:text-ink"
            >
              {item.label}
              <span className="absolute -bottom-1 left-0 h-0.5 w-0 bg-sage transition-all group-hover:w-full" />
            </Link>
          ))}
        </div>

        <div className="hidden lg:block">
          <Button href="/booking" size="sm">
            Book træning
          </Button>
        </div>

        <button
          type="button"
          className="rounded-xl p-2 hover:bg-sand lg:hidden"
          onClick={() => setIsOpen((open) => !open)}
          aria-label={isOpen ? "Luk menu" : "Åbn menu"}
        >
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-3 border-t border-sand bg-cream/95 lg:hidden"
          >
            <div className="container-custom flex flex-col gap-3 py-6">
              {siteConfig.nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="py-1 text-lg font-medium text-ink"
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <Button href="/booking" className="mt-2 w-full">
                Book træning
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
