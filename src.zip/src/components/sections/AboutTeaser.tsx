"use client";

import Image from "next/image";
import { Button } from "@/components/ui/Button";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { AnimatedSection } from "@/components/ui/AnimatedSection";
import { siteConfig } from "@/lib/utils";

export function AboutTeaser() {
  return (
    <AnimatedSection>
      <div className="container-custom grid items-center gap-12 lg:grid-cols-2">
        <div className="relative aspect-[4/5] overflow-hidden rounded-3xl shadow-premium">
          <Image
            src="https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=900&q=80"
            alt={`${siteConfig.trainer}, personlig træner`}
            fill
            className="object-cover"
          />
        </div>
        <div>
          <SectionHeading
            align="left"
            eyebrow="Om mig"
            title={`Hej, jeg hedder ${siteConfig.trainer}`}
            description="Jeg hjælper travle mennesker med at blive stærkere, bevæge sig bedre og holde træningen — uden at livet skal dreje sig om gymmet."
          />
          <p className="mb-4 leading-relaxed text-ink/70">
            Sessionerne er 1:1. Vi træner med det, du har brug for: styrke, teknik,
            mobilitet og et program, der kan overleve en travl uge.
          </p>
          <p className="mb-8 leading-relaxed text-ink/70">
            Du kan booke en enkelt time, eller vi kan lægge et forløb, hvor vi følger
            hinanden over 4, 8 eller 12 uger.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button href="/om">Læs mere</Button>
            <Button href="/booking" variant="outline">
              Book en tid
            </Button>
          </div>
        </div>
      </div>
    </AnimatedSection>
  );
}
