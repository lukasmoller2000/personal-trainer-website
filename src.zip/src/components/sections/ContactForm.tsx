"use client";

import { useState } from "react";
import { CheckCircle, Send } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { AnimatedSection } from "@/components/ui/AnimatedSection";

export function ContactForm({ showHeading = true }: { showHeading?: boolean }) {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  if (submitted) {
    return (
      <AnimatedSection>
        <div className="container-custom max-w-xl py-12 text-center">
          <CheckCircle className="mx-auto mb-5 h-14 w-14 text-sage" />
          <h2 className="font-display text-3xl font-semibold text-ink">Tak for din besked</h2>
          <p className="mt-3 text-lg text-ink/70">Jeg vender tilbage hurtigst muligt — typisk inden for 24 timer.</p>
        </div>
      </AnimatedSection>
    );
  }

  return (
    <AnimatedSection id="kontakt">
      <div className="container-custom max-w-3xl">
        {showHeading && (
          <SectionHeading
            eyebrow="Kontakt"
            title="Skriv, hvis du er i tvivl"
            description="Vil du hellere spørge, før du booker? Send en kort besked, så tager vi den derfra."
          />
        )}
        <Card hover={false}>
          <form
            className="space-y-5"
            onSubmit={(event) => {
              event.preventDefault();
              setSubmitted(true);
            }}
          >
            <div className="grid gap-5 md:grid-cols-2">
              <Field
                id="name"
                label="Navn"
                value={formData.name}
                onChange={(value) => setFormData((prev) => ({ ...prev, name: value }))}
              />
              <Field
                id="phone"
                label="Telefon"
                type="tel"
                value={formData.phone}
                onChange={(value) => setFormData((prev) => ({ ...prev, phone: value }))}
              />
            </div>
            <Field
              id="email"
              label="Email"
              type="email"
              value={formData.email}
              onChange={(value) => setFormData((prev) => ({ ...prev, email: value }))}
            />
            <div>
              <label htmlFor="message" className="mb-2 block text-sm font-medium text-ink">
                Besked
              </label>
              <textarea
                id="message"
                required
                rows={5}
                value={formData.message}
                onChange={(event) => setFormData((prev) => ({ ...prev, message: event.target.value }))}
                className="w-full resize-none rounded-2xl border border-sand bg-white px-4 py-3 outline-none ring-sage/40 focus:ring-2"
                placeholder="Hvad vil du gerne have hjælp til?"
              />
            </div>
            <Button type="submit" size="lg">
              <Send className="h-5 w-5" />
              Send besked
            </Button>
          </form>
        </Card>
      </div>
    </AnimatedSection>
  );
}

function Field({
  id,
  label,
  value,
  onChange,
  type = "text",
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm font-medium text-ink">
        {label}
      </label>
      <input
        id={id}
        name={id}
        type={type}
        required
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-2xl border border-sand bg-white px-4 py-3 outline-none ring-sage/40 focus:ring-2"
      />
    </div>
  );
}
