"use client";

import { CalendarCheck, MessageCircle, Dumbbell, TrendingUp } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { AnimatedSection } from "@/components/ui/AnimatedSection";

const steps = [
  {
    icon: CalendarCheck,
    title: "Book online",
    text: "Vælg én session eller et forløb, og find en tid der passer.",
  },
  {
    icon: MessageCircle,
    title: "Kort intro",
    text: "Vi starter med mål, skader og hverdag, så programmet rammer rigtigt.",
  },
  {
    icon: Dumbbell,
    title: "Træn 1:1",
    text: "Teknik, styrke og tempo — uden at spilde tiden på det, du ikke har brug for.",
  },
  {
    icon: TrendingUp,
    title: "Juster og byg videre",
    text: "Vi følger fremgang og justerer, så du bliver ved med at rykke.",
  },
];

export function HowItWorks() {
  return (
    <AnimatedSection className="bg-sand/40">
      <div className="container-custom">
        <SectionHeading
          eyebrow="Sådan foregår det"
          title="Fra booking til resultater"
          description="Ingen indmeldelsesgebyr. Ingen binding ud over det forløb, du selv vælger."
        />
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <div key={step.title} className="rounded-3xl bg-white p-6 shadow-soft">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-forest text-cream">
                  <step.icon className="h-6 w-6" />
                </div>
                <span className="font-display text-2xl text-sand">0{index + 1}</span>
              </div>
              <h3 className="font-display text-xl font-semibold text-ink">{step.title}</h3>
              <p className="mt-2 text-ink/70">{step.text}</p>
            </div>
          ))}
        </div>
      </div>
    </AnimatedSection>
  );
}
