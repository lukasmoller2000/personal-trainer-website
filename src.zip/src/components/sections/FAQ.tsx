"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Minus, Plus } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { AnimatedSection } from "@/components/ui/AnimatedSection";
import { cn } from "@/lib/utils";

export const faqs = [
  {
    question: "Kan jeg booke bare én træning?",
    answer:
      "Ja. Du kan booke en enkelt 60-minutters session uden at binde dig til et forløb. Mange starter der, og vælger bagefter Kickstart eller Transformation.",
  },
  {
    question: "Hvad er forskellen på en session og et forløb?",
    answer:
      "En session er én time. Et forløb er et sæt sessioner over 4, 8 eller 12 uger med et samlet program, opfølgning og en lavere pris pr. time.",
  },
  {
    question: "Hvor foregår træningen?",
    answer:
      "I København — typisk i et partnercenter på Nørrebro. Har du et andet sted, der passer bedre, skriver vi det ind i bookingen og finder en løsning.",
  },
  {
    question: "Hvad skal jeg have med?",
    answer:
      "Træningstøj, indendørssko og en vandflaske. Jeg sørger for program og udstyr. Sig til, hvis du har skader eller begrænsninger.",
  },
  {
    question: "Kan jeg aflyse eller flytte?",
    answer:
      "Ja, senest 24 timer før. Senere afbud tæller som brugt session ved forløb, og som fuld pris ved enkeltbooking.",
  },
  {
    question: "Hvordan betaler jeg?",
    answer:
      "Efter booking får du en bekræftelse. Betaling aftales via MobilePay eller bankoverførsel inden første session. Online betaling kan tilføjes senere.",
  },
];

export function FAQ({ limit, showHeading = true }: { limit?: number; showHeading?: boolean }) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const items = limit ? faqs.slice(0, limit) : faqs;

  return (
    <AnimatedSection id="faq" className="bg-sand/40">
      <div className="container-custom max-w-3xl">
        {showHeading && (
          <SectionHeading
            eyebrow="FAQ"
            title="Det, folk plejer at spørge om"
            description="Er der noget, der ikke står her, så skriv — så svarer jeg."
          />
        )}
        <div className="space-y-3">
          {items.map((faq, index) => (
            <div key={faq.question} className="overflow-hidden rounded-2xl border border-sand bg-white shadow-soft">
              <button
                type="button"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="flex w-full items-center justify-between p-5 text-left"
                aria-expanded={openIndex === index}
              >
                <span className="pr-4 font-medium text-ink">{faq.question}</span>
                <span
                  className={cn(
                    "flex h-8 w-8 shrink-0 items-center justify-center rounded-xl",
                    openIndex === index ? "bg-sage text-white" : "bg-sand text-ink"
                  )}
                >
                  {openIndex === index ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                </span>
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                  >
                    <p className="px-5 pb-5 leading-relaxed text-ink/70">{faq.answer}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </AnimatedSection>
  );
}
