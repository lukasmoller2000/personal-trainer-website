"use client";

import Link from "next/link";
import { ArrowRight, Check } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { AnimatedSection } from "@/components/ui/AnimatedSection";
import { Button } from "@/components/ui/Button";
import { products } from "@/lib/products";
import { formatPrice } from "@/lib/utils";

export function Offerings({ compact = false }: { compact?: boolean }) {
  const items = compact ? products.filter((p) => p.id === "session" || p.popular) : products;

  return (
    <AnimatedSection id="ydelser">
      <div className="container-custom">
        <SectionHeading
          eyebrow="Ydelser"
          title="Vælg en enkelt træning eller et forløb"
          description="Start med én session, hvis du vil mærke stilen. Eller gå all-in på et forløb, hvor vi arbejder systematisk over uger."
        />

        <div className={`grid gap-6 ${compact ? "md:grid-cols-2 max-w-4xl mx-auto" : "md:grid-cols-2 xl:grid-cols-4"}`}>
          {items.map((product) => (
            <Card key={product.id} className="relative flex h-full flex-col">
              {product.popular && (
                <span className="absolute right-5 top-5 rounded-full bg-gold/20 px-3 py-1 text-xs font-semibold text-forest">
                  Mest valgt
                </span>
              )}
              <p className="text-sm font-medium uppercase tracking-widest text-sage">
                {product.kind === "session" ? "Session" : "Forløb"}
              </p>
              <h3 className="mt-2 font-display text-2xl font-semibold text-ink">{product.name}</h3>
              <p className="mt-1 text-ink/55">{product.tagline}</p>
              <p className="mt-4 font-display text-3xl font-semibold text-ink">
                {formatPrice(product.price)}
              </p>
              <p className="mt-4 flex-1 text-sm leading-relaxed text-ink/70">{product.description}</p>
              <ul className="mt-6 space-y-2">
                {product.perks.map((perk) => (
                  <li key={perk} className="flex items-start gap-2 text-sm text-ink/80">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-sage" />
                    {perk}
                  </li>
                ))}
              </ul>
              <Button href={`/booking?produkt=${product.id}`} className="mt-8 w-full">
                Book {product.kind === "session" ? "session" : "forløb"}
              </Button>
            </Card>
          ))}
        </div>

        {compact && (
          <div className="mt-10 text-center">
            <Link href="/ydelser" className="inline-flex items-center gap-2 font-medium text-sage hover:text-forest">
              Se alle forløb
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        )}
      </div>
    </AnimatedSection>
  );
}
