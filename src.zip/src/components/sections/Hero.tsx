"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight, CalendarCheck } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { siteConfig } from "@/lib/utils";

export function Hero() {
  return (
    <section className="relative flex min-h-screen items-center overflow-hidden">
      <div className="absolute inset-0">
        <Image
          src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=1920&q=80"
          alt="Personlig træning i gym"
          fill
          priority
          className="object-cover object-center"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/90 via-ink/70 to-ink/35" />
      </div>

      <div className="container-custom relative z-10 pt-32 pb-24">
        <div className="max-w-3xl">
          <motion.span
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm text-cream/90 backdrop-blur"
          >
            <span className="h-2 w-2 animate-pulse rounded-full bg-moss" />
            Personlig træner i {siteConfig.location}
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="font-display text-5xl font-semibold leading-[1.08] text-cream text-balance md:text-7xl"
          >
            Træning der passer til dit liv — ikke omvendt.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-6 max-w-xl text-lg leading-relaxed text-cream/80 md:text-xl"
          >
            Book en enkelt personlig træning, eller start et forløb med {siteConfig.trainer}.
            Klare mål, ærlig feedback og et program du faktisk kan holde.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-10 flex flex-col gap-4 sm:flex-row"
          >
            <Button href="/booking" size="lg" className="group">
              Book 1 træning eller forløb
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button
              href="/ydelser"
              variant="outline"
              size="lg"
              className="border-white/30 text-cream hover:border-white/50 hover:bg-white/10"
            >
              <CalendarCheck className="h-5 w-5" />
              Se ydelser
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
