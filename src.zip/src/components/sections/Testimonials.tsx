"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { AnimatedSection } from "@/components/ui/AnimatedSection";

const testimonials = [
  {
    quote:
      "Jeg startede med én session for at se, om det var noget. Tre måneder senere er jeg stærkere, og træningen passer endelig ind i ugen.",
    name: "Mette K.",
    role: "Transformation, 8 uger",
  },
  {
    quote:
      "Ingen fluff. Vi retter teknik, løfter tungt nok og går hjem med et program, jeg faktisk bruger.",
    name: "Jonas H.",
    role: "Kickstart, 4 uger",
  },
  {
    quote:
      "Jeg havde ondt i ryggen og var træt af holdtimer. Her bliver der lyttet, og jeg kan mærke forskel i hverdagen.",
    name: "Sofie L.",
    role: "1 personlig træning + forløb",
  },
];

export function Testimonials() {
  const [current, setCurrent] = useState(0);
  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <AnimatedSection className="bg-forest text-cream">
      <div className="container-custom">
        <SectionHeading
          eyebrow="Klienter"
          title="Det siger de, der træner her"
          className="[&_h2]:text-cream [&_p]:text-cream/70"
        />
        <div className="relative mx-auto max-w-3xl rounded-3xl border border-white/10 bg-white/5 p-8 md:p-12">
          <Quote className="mb-6 h-10 w-10 text-gold" />
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
            >
              <p className="font-display text-2xl leading-relaxed md:text-3xl">
                “{testimonials[current].quote}”
              </p>
              <p className="mt-8 font-semibold">{testimonials[current].name}</p>
              <p className="text-cream/60">{testimonials[current].role}</p>
            </motion.div>
          </AnimatePresence>
          <div className="mt-8 flex items-center gap-3">
            <button
              type="button"
              onClick={prev}
              aria-label="Forrige"
              className="flex h-11 w-11 items-center justify-center rounded-2xl border border-white/15 hover:bg-white/10"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={next}
              aria-label="Næste"
              className="flex h-11 w-11 items-center justify-center rounded-2xl border border-white/15 hover:bg-white/10"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </AnimatedSection>
  );
}
