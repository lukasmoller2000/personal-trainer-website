"use client";

import { Dumbbell, Users, Timer, Star } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { AnimatedSection } from "@/components/ui/AnimatedSection";

const stats = [
  { icon: Dumbbell, value: "1:1", label: "Altid personligt", hint: "Ingen hold, ingen støj" },
  { icon: Timer, value: "60 min", label: "Pr. session", hint: "Fuld fokus på dig" },
  { icon: Users, value: "4–12 uger", label: "Forløb", hint: "Fra kickstart til elite" },
  { icon: Star, value: "4.9/5", label: "Klienter", hint: "Baseret på forløb" },
];

export function Stats() {
  return (
    <AnimatedSection className="relative z-20 -mt-16 bg-transparent pt-0 pb-8 md:pb-12">
      <div className="container-custom grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="text-center">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-sage/10">
              <stat.icon className="h-6 w-6 text-sage" />
            </div>
            <div className="font-display text-3xl font-semibold text-ink">{stat.value}</div>
            <div className="mt-1 font-medium text-ink">{stat.label}</div>
            <div className="text-sm text-ink/55">{stat.hint}</div>
          </Card>
        ))}
      </div>
    </AnimatedSection>
  );
}
